const images = {
    logo: require('../images/logo.png'),
    banner1: require('../images/banner1.jpeg'),
    banner2: require('../images/banner2.png'),
    banner3: require('../images/banner3.jpeg'),
    banner4: require('../images/banner4.jpeg'),
    chevronLeft: require('../images/chevron-left-solid.svg'),
};

export default images;
