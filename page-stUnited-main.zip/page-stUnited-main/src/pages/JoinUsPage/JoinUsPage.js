import JoinUs from '../../component/template/Joinus/joinus';

const JoinUsPage =() => {
    return <JoinUs />
}

export default JoinUsPage;
