// import StDigital from '~/src/component/template/StDigital/StDigital';
import StDigital from '../../component/template/STDigital/StDigital';

const StDigitalPage = () => {
    return <StDigital />;
};
export default StDigitalPage;
