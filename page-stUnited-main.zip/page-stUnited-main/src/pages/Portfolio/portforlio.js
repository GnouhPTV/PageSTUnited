import Portforlio from '../../component/template/Portforlio/portforlio';

function Portfolio() {
    return <Portforlio />;
}

export default Portfolio;
