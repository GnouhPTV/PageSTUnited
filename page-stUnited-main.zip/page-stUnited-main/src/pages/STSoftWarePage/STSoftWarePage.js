import StSortWare from '../../component/template/STSoftware/Stsoftware';

const StSortWarePage = () => {
    return <StSortWare />;
};
export default StSortWarePage;
