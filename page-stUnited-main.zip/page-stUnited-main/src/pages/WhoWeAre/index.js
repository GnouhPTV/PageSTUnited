import WhoWeAre from '../../component/template/WhoWeAre/whoweare';

const Pagewhoweare = () => {
    return <WhoWeAre />;
};
export default Pagewhoweare;
