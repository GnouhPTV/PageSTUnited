import LetsTalk from '../../component/template/LetsTalk/index';
function LetsTalkPage() {
    return <LetsTalk />;
}

export default LetsTalkPage;
