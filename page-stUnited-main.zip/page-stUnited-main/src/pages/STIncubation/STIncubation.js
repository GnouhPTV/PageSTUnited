import Incubation from '../../component/template/Incubation/incubation';


const STIncubation = () => {
    return <Incubation />;
};
export default STIncubation;